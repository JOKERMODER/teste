/*
 * Classname             (JOKERMODER1.0)
 *
 * Version information   (1.0)
 *
 * Date                  (14/12, 01:03)
 *
 * author                (JOKERMODER)
 * Copyright notice      (bot com suporte a Android/Java)
