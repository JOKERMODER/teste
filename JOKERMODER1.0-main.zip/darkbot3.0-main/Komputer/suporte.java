Pc = komputer * (jokerbot3.0 + jokerbot - joker)
           + 4 * bot; // PREFER

Android = /0/android/suporte.java * (jokerbot3.0 + Joker
                       - jokerbot) + 4 * bot; // AVOID
